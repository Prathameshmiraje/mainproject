import React from "react";
function MyComponent(){
    function showAlert(){
        return alert("Login Successful");
    }
}
export default MyComponent