import React from 'react'

const Student = () => {
  return (
    <div>
      I am in student
    </div>
  )
}

export default Student
