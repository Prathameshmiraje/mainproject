import React from 'react'

const Admin = () => {
  return (
    <div>
      I am in Admin
    </div>
  )
}

export default Admin
