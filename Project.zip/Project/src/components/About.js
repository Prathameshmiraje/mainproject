import React from 'react'

function About() {
  return (
    <div>
      this is about
    </div>
  )
}

export default About
