const mongoose = require('mongoose');
const { Schema } = mongoose;

const adminSchema = new Schema({
    empid : {
    type : Number,
    required : true
   },
   name : {
    type : String,
    required : true
   },
   Password : {
    type : String,
    required : true
   }

  });

  module.exports = mongoose.model('admin', adminSchema);