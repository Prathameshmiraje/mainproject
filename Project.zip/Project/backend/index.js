const connectToMongo = require('./db');
const express = require('express');
var cors = require('cors')

connectToMongo();



const app = express()
const port = 5000

app.use(cors())

app.use(express.json())


// Available routes
app.use('/api/student/', require('./routes/student'))
app.use('/api/faculty/', require('./routes/faculty'))
app.use('/api/coordinator/', require('./routes/cordinator'))
app.use('/api/updatedelstudent/', require('./routes/updatedelstudent'))
app.use('/api/updatedelfaculty/', require('./routes/updatedelfaculty'))
app.use('/api/updatedelcoordinator/', require('./routes/updatedelcoordinator'))
app.use('/api/admin/', require('./routes/admin'))

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})