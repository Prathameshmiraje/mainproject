const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const students = require('../models/Students');
const bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
var fetchstudent = require('../middleware/fetchstudent');

const JWT_SECRET = 'JaiShriRam';


//Route 1 Create a students using:Post "/api/auth/addStudents". Doesn't require Auth
router.post('/addStudents',[
    body('rollNo', 'Enter a valid rollNo').isInt(),
    body('name', 'Enter a valid name').isLength({ min: 3 }),
    body('Password', 'Enter a valid password').isLength({ min: 3 }),
    body('attendence', 'Enter valid attendence').notEmpty(),
    body('sub1','Enter valid marks' ).notEmpty(),
    body('sub2','Enter valid marks' ).notEmpty(),
    body('sub3','Enter valid marks' ).notEmpty(),

],async(req, res) => {
  // If there is are errors, return bad request and the errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    // Check weather this rollNo exist already
    try{

    
    let student = await students.findOne({rollNo: req.body.rollNo});
    if(student){
      return res.status(400).json({error: "Sorry a student with this rollnumber already exists"})
    }

    const salt = await bcrypt.genSalt(10);
    const secPass = await bcrypt.hash(req.body.Password, salt) ;

    // add a new student
    student = await students.create({
        rollNo: req.body.rollNo,
        name: req.body.name,
        Password: secPass,
        attendence: req.body.attendence,
        sub1: req.body.sub1,
        sub2: req.body.sub2,
        sub3: req.body.sub3
      })
    
      const data = {
        student:{
          id : student.id
        }
      }
      const authtoken = jwt.sign(data, JWT_SECRET);
      
      //res.json(student);
      res.json({authtoken})

    }catch(error){
      console.error(error.message);
      res.status(500).send("Some error occured");
    }
   
})

//Rpute 2 Authenticate a students using:Post "/api/auth/login". no login required
router.post('/login',[
  body('rollNo', 'Enter a valid rollNo').isInt(),
  body('Password', 'Password cannot be blank').exists(),

],async(req, res) => {
   // If there is are errors, return bad request and the errors
   const errors = validationResult(req);
   if (!errors.isEmpty()) {
     return res.status(400).json({ errors: errors.array() });
   }

   const {rollNo, Password} = req.body;
   try {
      let student = await students.findOne({rollNo});
      if(!student){
        return res.status(400).json({error: "Please try to login with correct credentials"});
      }

      const passwordCompare = await bcrypt.compare(Password, student.Password);
      if(!passwordCompare){
        return res.status(400).json({error: "Please try to login with correct credentials"});
      }

      const data = {
        student:{
          id : student.id
        }
      }
      const authtoken = jwt.sign(data, JWT_SECRET);

      res.json({authtoken})

    }catch(error){
      console.error(error.message);
      res.status(500).send("Internal server error occured");
    }
})

//Rpute 3 get logged in students detail:Post "/api/auth/getstudent". login required
router.post('/getstudent',fetchstudent,async(req, res) => {
try {
  studentId = req.student.id;
  const student = await students.findById(studentId).select("-Password");
  res.send(student);
}catch(error){
  console.error(error.message);
  res.status(500).send("Internal server error occured");
}
})

module.exports = router