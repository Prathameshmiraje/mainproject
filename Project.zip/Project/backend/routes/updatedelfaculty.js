const express = require("express");
const router = express.Router();
const { body, validationResult } = require("express-validator");
var fetchcoordinator = require("../middleware/fetchCoordinator");
const Faculty = require("../models/Faculty");
const bcrypt = require("bcryptjs");
var jwt = require("jsonwebtoken");

// Route 1 : Get all the facultys, Login required
router.get("/fetchallfaculty", fetchcoordinator, async (req, res) => {
  try {
    const faculty = await Faculty.find({ coordinator: req.coordinator.id });
    res.json(faculty);
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Some error occured");
  }
});

// Route 2 : Add facultys using post, Login required
router.post(
  "/addfaculty",
  fetchcoordinator,
  [
    body("empid", "Enter a valid empid").isInt(),
    body("name", "Enter a valid name").isLength({ min: 3 }),
    body("Password", "Enter a valid password").isLength({ min: 3 }),
    body("subject", "Enter valid subject").notEmpty(),
  ],
  async (req, res) => {
    try {
      const { empid, name, Password, subject } = req.body;
      // If there is are errors, return bad request and the errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      let faculty = await Faculty.findOne({ empid: req.body.empid });
      if (faculty) {
        return res.status(400).json({
          error: "Sorry a faculty with this rollnumber already exists",
        });
      }

      const salt = await bcrypt.genSalt(10);
      const secPass = await bcrypt.hash(req.body.Password, salt);

      // add a new faculty

      faculty = new Faculty({
        empid,
        name,
        Password: secPass,
        subject,
        coordinator: req.coordinator.id,
      });
      const savedStudent = await faculty.save();

      res.json(savedStudent);
    } catch (error) {
      console.error(error.message);
      res.status(500).send("Some error occured");
    }
  }
);

//Route 3 Update an existing faculty data using put. login required.
router.put("/updatefaculty/:id", fetchcoordinator, async (req, res) => {
  const { empid, name, Password, subject } = req.body;
  try {
    //Create a newnote object

    const newfaculty = {};
    if (empid) {
      newfaculty.empid = empid;
    }
    if (name) {
      newfaculty.name = name;
    }
    if (Password) {
      newfaculty.Password = Password;
    }
    if (subject) {
      newfaculty.subject = subject;
    }

    //Find the faculty and update it
    let faculty = await Faculty.findById(req.params.id);
    if (!faculty) {
      return res.status(404).send("Not Found");
    }

    if (faculty.coordinator.toString() !== req.coordinator.id) {
      return res.status(401).send("Not Allowed");
    }

    faculty = await Faculty.findByIdAndUpdate(
      req.params.id,
      { $set: newfaculty },
      { new: true }
    );
    res.json({ faculty });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Some error occured");
  }
});

//Route 4 delete an existing faculty data using delete. login required.
router.delete("/deletefaculty/:id", fetchcoordinator, async (req, res) => {
  try {
    //Find the faculty and delete it
    let faculty = await Faculty.findById(req.params.id);
    if (!faculty) {
      return res.status(404).send("Not Found");
    }

    // allow deletion if user owns this faculty
    if (faculty.coordinator.toString() !== req.coordinator.id) {
      return res.status(401).send("Not Allowed");
    }

    faculty = await Faculty.findByIdAndDelete(req.params.id);
    res.json({ Success: "faculty data has been deleted", faculty: faculty });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Some error occured");
  }
});

module.exports = router;
