const express = require('express');
const coordinators = require('../models/coordinator')
const router = express.Router();
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
var fetchCoordinator = require('../middleware/fetchCoordinator');

const JWT_SECRET = 'Prathameshis$Great';


//Route 1 Create a Faculty using:Post "/api/coordinator/addCoordinator". Doesn't require Auth
router.post('/addCoordinator',[
    body('empid', 'Enter a valid empid').isInt(),
    body('name', 'Enter a valid name').isLength({ min: 3 }),
    body('Password', 'Enter a valid password').isLength({ min: 3 }),
    

],async(req, res) => {
  // If there is are errors, return bad request and the errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    // Check weather this empid exist already
    try{

    
    let coordinator = await coordinators.findOne({empid: req.body.empid});
    if(coordinator){
      return res.status(400).json({error: "Sorry a faculty with this rollnumber already exists"})
    }

    const salt = await bcrypt.genSalt(10);
    const secPass = await bcrypt.hash(req.body.Password, salt) ;

    // add a new coordinator
    coordinator = await coordinators.create({
        empid: req.body.empid,
        name: req.body.name,
        Password: secPass,
       
      })
    
      const data = {
        coordinator:{
          id : coordinator.id
        }
      }
      const authtoken = jwt.sign(data, JWT_SECRET);
      
      //res.json(faculty);
      res.json({authtoken})

    }catch(error){
      console.error(error.message);
      res.status(500).send("Some error occured");
    }
   
})

//Rpute 2 Authenticate a Faculty using:Post "/api/coordinator/login". no login required
router.post('/login',[
  body('empid', 'Enter a valid empid').isInt(),
  body('Password', 'Password cannot be blank').exists(),

],async(req, res) => {
   // If there is are errors, return bad request and the errors
   const errors = validationResult(req);
   if (!errors.isEmpty()) {
     return res.status(400).json({ errors: errors.array() });
   }

   const {empid, Password} = req.body;
   try {
      let coordinator = await coordinators.findOne({empid});
      if(!coordinator){
        return res.status(400).json({error: "Please try to login with correct credentials"});
      }

      const passwordCompare = await bcrypt.compare(Password, coordinator.Password);
      if(!passwordCompare){
        return res.status(400).json({error: "Please try to login with correct credentials"});
      }

      const data = {
        coordinator:{
          id : coordinator.id
        }
      }
      const authtoken = jwt.sign(data, JWT_SECRET);

      res.json({authtoken})

    }catch(error){
      console.error(error.message);
      res.status(500).send("Internal server error occured");
    }
})

//Rpute 3 get logged in Faculty detail:Post "/api/coordinator/getcoordinator". login required
router.post('/getCoordinator',fetchCoordinator,async(req, res) => {
try {
  coordinatorId = req.coordinator.id;
  const coordinator = await coordinators.findById(coordinatorId).select("-Password");
  res.send(coordinator);
}catch(error){
  console.error(error.message);
  res.status(500).send("Internal server error occured");
}
})

module.exports = router