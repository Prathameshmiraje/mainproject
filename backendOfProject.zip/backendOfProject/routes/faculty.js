const express = require('express');
const faculties = require('../models/Faculty');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
var fetchFaculty = require('../middleware/fetchFaculty');

const JWT_SECRET = 'Prathameshis$Great';


//Route 1 Create a Faculty using:Post "/api/faculty/addFaculty". Doesn't require Auth
router.post('/addFaculty',[
    body('empid', 'Enter a valid empid').isInt(),
    body('name', 'Enter a valid name').isLength({ min: 3 }),
    body('Password', 'Enter a valid password').isLength({ min: 3 }),
    body('subject', 'Enter valid subject').notEmpty(),
    

],async(req, res) => {
  // If there is are errors, return bad request and the errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    // Check weather this empid exist already
    try{

    
    let faculty = await faculties.findOne({empid: req.body.empid});
    if(faculty){
      return res.status(400).json({error: "Sorry a faculty with this rollnumber already exists"})
    }

    const salt = await bcrypt.genSalt(10);
    const secPass = await bcrypt.hash(req.body.Password, salt) ;

    // add a new faculty
    faculty = await faculties.create({
        empid: req.body.empid,
        name: req.body.name,
        Password: secPass,
        subject: req.body.subject,
       
      })
    
      const data = {
        faculty:{
          id : faculty.id
        }
      }
      const authtoken = jwt.sign(data, JWT_SECRET);
      
      //res.json(faculty);
      res.json({authtoken})

    }catch(error){
      console.error(error.message);
      res.status(500).send("Some error occured");
    }
   
})

//Rpute 2 Authenticate a Faculty using:Post "/api/faculty/login". no login required
router.post('/login',[
  body('empid', 'Enter a valid empid').isInt(),
  body('Password', 'Password cannot be blank').exists(),

],async(req, res) => {
   // If there is are errors, return bad request and the errors
   const errors = validationResult(req);
   if (!errors.isEmpty()) {
     return res.status(400).json({ errors: errors.array() });
   }

   const {empid, Password} = req.body;
   try {
      let faculty = await faculties.findOne({empid});
      if(!faculty){
        return res.status(400).json({error: "Please try to login with correct credentials"});
      }

      const passwordCompare = await bcrypt.compare(Password, faculty.Password);
      if(!passwordCompare){
        return res.status(400).json({error: "Please try to login with correct credentials"});
      }

      const data = {
        faculty:{
          id : faculty.id
        }
      }
      const authtoken = jwt.sign(data, JWT_SECRET);

      res.json({authtoken})

    }catch(error){
      console.error(error.message);
      res.status(500).send("Internal server error occured");
    }
})

//Rpute 3 get logged in Faculty detail:Post "/api/faculty/getfaculty". login required
router.post('/getfaculty',fetchFaculty,async(req, res) => {
try {
  facultyId = req.faculty.id;
  const faculty = await faculties.findById(facultyId).select("-Password");
  res.send(faculty);
}catch(error){
  console.error(error.message);
  res.status(500).send("Internal server error occured");
}
})

module.exports = router