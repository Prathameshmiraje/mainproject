const express = require("express");
const router = express.Router();
const { body, validationResult } = require("express-validator");
var fetchadmin = require("../middleware/fetchAdmin");
const Coordinator = require("../models/coordinator");
const bcrypt = require("bcryptjs");
var jwt = require("jsonwebtoken");

// Route 1 : Get all the coordinators, Login required
router.get("/fetchallcoordinator", fetchadmin, async (req, res) => {
  try {
    const coordinator = await Coordinator.find({ admin: req.admin.id });
    res.json(coordinator);
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Some error occured");
  }
});

// Route 2 : Add coordinators using post, Login required
router.post(
  "/addcoordinators",
  fetchadmin,
  [
    body("empid", "Enter a valid empid").isInt(),
    body("name", "Enter a valid name").isLength({ min: 3 }),
    body("Password", "Enter a valid password").isLength({ min: 3 }),
  ],
  async (req, res) => {
    try {
      const { empid, name, Password } = req.body;
      // If there is are errors, return bad request and the errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      let coordinator = await Coordinator.findOne({ empid: req.body.empid });
      if (coordinator) {
        return res.status(400).json({
          error: "Sorry a coordinator with this rollnumber already exists",
        });
      }

      const salt = await bcrypt.genSalt(10);
      const secPass = await bcrypt.hash(req.body.Password, salt);

      // add a new coordinator

      coordinator = new Coordinator({
        empid,
        name,
        Password: secPass,
        admin: req.admin.id,
      });
      const savedCoordinator = await coordinator.save();

      res.json(savedCoordinator);
    } catch (error) {
      console.error(error.message);
      res.status(500).send("Some error occured");
    }
  }
);

//Route 3 Update an existing coordinator data using put. login required.
router.put("/updatecoordinator/:id", fetchadmin, async (req, res) => {
  const { empid, name, Password } = req.body;
  try {
    //Create a newnote object

    const newcoordinator = {};
    if (empid) {
      newcoordinator.empid = empid;
    }
    if (name) {
      newcoordinator.name = name;
    }
    if (Password) {
      newcoordinator.Password = Password;
    }
   

    //Find the coordinator and update it
    let coordinator = await Coordinator.findById(req.params.id);
    if (!coordinator) {
      return res.status(404).send("Not Found");
    }

    if (coordinator.admin.toString() !== req.admin.id) {
      return res.status(401).send("Not Allowed");
    }

    coordinator = await Coordinator.findByIdAndUpdate(
      req.params.id,
      { $set: newcoordinator },
      { new: true }
    );
    res.json({ coordinator });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Some error occured");
  }
});

//Route 4 delete an existing coordinator data using delete. login required.
router.delete("/deletecoordinator/:id", fetchadmin, async (req, res) => {
  try {
    //Find the coordinator and delete it
    let coordinator = await Coordinator.findById(req.params.id);
    if (!coordinator) {
      return res.status(404).send("Not Found");
    }

    // allow deletion if user owns this coordinator
    if (coordinator.admin.toString() !== req.admin.id) {
      return res.status(401).send("Not Allowed");
    }

    coordinator = await Coordinator.findByIdAndDelete(req.params.id);
    res.json({ Success: "coordinator data has been deleted", coordinator: coordinator });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Some error occured");
  }
});

module.exports = router;
