const connectToMongo = require('./db');
const express = require('express')

connectToMongo();



const app = express()
const port = 5000

app.use(express.json())


// Available routes
app.use('/api/auth/', require('./routes/auth'))
app.use('/api/faculty/', require('./routes/faculty'))
app.use('/api/coordinator/', require('./routes/cordinator'))
app.use('/api/updatedelstudent/', require('./routes/updatedelstudent'))
app.use('/api/updatedelfaculty/', require('./routes/updatedelfaculty'))
app.use('/api/updatedelcoordinator/', require('./routes/updatedelcoordinator'))
app.use('/api/admin/', require('./routes/admin'))

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})