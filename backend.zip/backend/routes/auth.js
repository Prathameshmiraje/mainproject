const express = require('express');
const Students = require('../models/students');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const students = require('../models/students');


// Create a students using:Post "/api/auth". Doesn't require Auth
router.post('/',[
    body('rollNo', 'Enter a valid rollNo').isInt(),
    body('name', 'Enter a valid name').isLength({ min: 3 }),
    body('Password', 'Enter a valid password').isLength({ min: 3 }),
    body('attendence', 'Enter valid attendence').notEmpty(),
    body('marks','Enter valid marks' ).notEmpty(),

],(req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    students.create({
        rollNo: req.body.rollNo,
        name: req.body.name,
        Password: req.body.Password,
        attendence: req.body.attendence,
        marks: req.body.marks
      }).then(students => res.json(students))
      .catch(err=>{console.log(err)
    res.json({error:'Please enter a unique value', message: err.message})})
    

   
})

module.exports = router