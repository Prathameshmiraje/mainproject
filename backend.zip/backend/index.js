const connectToMongo = require('./db');
const express = require('express')

connectToMongo();
if(connectToMongo()){
  console.log("Connected to Mongodb Sucessfully");
}


const app = express()
const port = 3000

app.use(express.json())


// Available routes
app.use('/api/auth', require('./routes/auth'))

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})