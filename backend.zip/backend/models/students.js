const mongoose = require('mongoose');
const { Schema } = mongoose;

const studentSchema = new Schema({
   rollNo : {
    type : Number,
    required : true,
   },
   name : {
    type : String,
    required : true
   },
   Password : {
    type : String,
    required : true
   },
   attendence : {
    type : Number,
    required : true
   },
   marks : [{
    java : {
        type : Number,
        required : true
       },
    sdm : {
        type : Number,
        required : true
       },
    wpt : {
        type : Number,
        required : true
       },
    }]

  });

  const Students = mongoose.model('students', studentSchema);
  Students.createIndexes();
  module.exports = Students;